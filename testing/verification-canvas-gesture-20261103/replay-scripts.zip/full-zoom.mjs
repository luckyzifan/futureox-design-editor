import fs from 'node:fs/promises'
import path from 'node:path'
import {createRequire} from 'node:module'
import {createHash} from 'node:crypto'
import assert from 'node:assert/strict'
const repository=process.cwd(),root=process.env.QA_WORKSPACE||process.cwd(),[source,out]=process.argv.slice(2),pixels=process.env.QA_PIXELS==='1',timing=process.env.QA_TIMING==='1'
if(!source||!out||!path.isAbsolute(source)||!path.isAbsolute(out))throw Error('Absolute source and fresh output required')
const require=createRequire(path.join(root,'frontend/design-client/package.json')),{_electron,expect}=require('@playwright/test')
const electron=createRequire(path.join(root,'frontend/design-desktop/package.json'))('electron')
const hash=b=>createHash('sha256').update(b).digest('hex'),sourceHash=hash(await fs.readFile(source))
const products=process.env.QA_PRODUCTS||path.join(root,'frontend/design-desktop/dist'),build=JSON.parse(await fs.readFile(path.join(products,'build-manifest.json'),'utf8'))
const drift=[];for(const [file,sha] of Object.entries(build.sources))if(hash(await fs.readFile(path.join(root,file)))!==sha)drift.push(file)
if(process.env.QA_BASELINE!=='1'&&drift.some(f=>!f.includes('.test.')))throw Error('Runtime source/build mismatch: '+drift.join(','))
if(process.env.QA_BASELINE==='1'){
 const frozen=JSON.parse(await fs.readFile(path.join(repository,'testing/verification-fluid-canvas-20261101/baseline-runtime.json'),'utf8')).sources
 for(const [file,sha] of Object.entries(build.sources))if(frozen[file]&&!file.includes('.test.')&&frozen[file]!==sha)throw Error('Baseline mismatch: '+file)
}
await fs.mkdir(out);await fs.mkdir(path.join(out,'profiles'));await fs.copyFile(new URL(import.meta.url),path.join(out,'replay.mjs'))
const host=path.join(out,'host');await fs.mkdir(host);await fs.cp(path.join(root,'frontend/design-desktop/src'),path.join(host,'src'),{recursive:true})
const main=path.join(host,'src/main.mjs');await fs.writeFile(main,(await fs.readFile(main,'utf8')).replace('backgroundThrottling: !renderCheck',process.env.QA_OFFSCREEN_INPUT==='1'?'backgroundThrottling: false, offscreen: {useSharedTexture: true}':'backgroundThrottling: false').replaceAll('ownedWindow.show()',process.env.QA_OFFSCREEN_INPUT==='1'?'void 0':'ownedWindow.showInactive()'))
await fs.symlink(products,path.join(host,'dist'));await fs.symlink(path.join(root,'frontend/design-desktop/assets'),path.join(host,'assets'))
await fs.writeFile(path.join(host,'package.json'),JSON.stringify({type:'module',main:'src/qa-launch.mjs'}))
await fs.writeFile(path.join(host,'src/qa-launch.mjs'),`import {NativePreparation} from './preparation.mjs';
import {LargeDocumentHost} from './large-document.mjs';
for(const method of ['open','canvasLayout','canvasSnapshot']){
 const fn=LargeDocumentHost.prototype[method];
 LargeDocumentHost.prototype[method]=async function(...args){
  const at=Date.now(),t=performance.now(),out=await fn.apply(this,args);
  console.log('QA_SOURCE_STAGE '+JSON.stringify({method,at,ms:performance.now()-t,roots:out.roots,nodes:out.nodes,bytes:out.bytes,bounds:out.bounds,items:out.items?.length}));return out;
 }
}
const original=NativePreparation.prototype.request;NativePreparation.prototype.request=function(input){const at=Date.now(),start=performance.now();let options;
if(input.method==='compile_gpu_packet')try{const p=JSON.parse(input.args[0]);options={view:p.view,gpuViewport:p.gpuViewport,captureViewport:p.captureViewport,width:p.width,height:p.height}}catch{}
return original.call(this,input).then(reply=>{if(['compile_gpu_packet','apply_document_patch_with_damage','apply_interaction_transforms','derive_document_v1'].includes(input.method))console.log('QA_NATIVE '+JSON.stringify({at,method:input.method,lane:input.lane,options,ms:performance.now()-start,error:reply.error,stats:reply.compileStats}));return reply})};await import('./main.mjs');`)
const env={...process.env,TMPDIR:path.join(out,'profiles'),CORE_RENDER_DIAGNOSTICS:process.env.QA_DETAIL==='1'?'detail':'1'};delete env.ELECTRON_RUN_AS_NODE
for(const key of ['CORE_SOURCE_SNAPSHOT_FORMAT','CORE_SOURCE_LAZY_LOAD','CORE_NATIVE_JSON_DECODER'])delete env[key]
const report={status:'running',inputIsolation:process.env.QA_ISOLATED_INPUT==='1',offscreen:process.env.QA_OFFSCREEN_INPUT==='1',offscreenSharedTexture:process.env.QA_OFFSCREEN_INPUT==='1',source,sourceHash,pixels,timing,builtAt:build.builtAt,nativeFeatures:build.nativeFeatures||[],diagnostic:build.qaDiagnostic,scriptHash:hash(await fs.readFile(new URL(import.meta.url))),cases:[],errors:[],drift}
const persist=()=>fs.writeFile(path.join(out,'report.json'),JSON.stringify(report,null,2));let app,page,cdp,stream,writes=[]
async function stage(name,fn){report.stage=name;await persist();const at=performance.now();try{const value=await fn();report.cases.push({name,status:'complete',wallMs:performance.now()-at,...value});return value}catch(e){report.cases.push({name,status:'failed',error:String(e)});throw e}finally{await persist();console.log(name)}}
async function settle(timeout=180000){if(process.env.QA_FULL_SOURCE==='1'){await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));await page.waitForFunction(()=>{const el=document.querySelector('.native-source-surface .kernel-status');return el?.textContent==='WebGPU · 清晰'||el?.textContent==='画板绘制未完成'},null,{timeout});const text=await page.locator('.native-source-surface .kernel-status').innerText();if(text==='画板绘制未完成')throw Error(await page.locator('.native-source-surface .kernel-status').getAttribute('title'));return}await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));await page.waitForFunction(()=>{const p=document.querySelector('.kernel-presentation')?.dataset,v=window.__qaEditor?.state.view;return document.querySelector('.kernel-status.error')||p?.presentationReady==='true'&&(!v||+p.cameraX===v.x&&+p.cameraY===v.y&&+p.cameraZoom===v.zoom)},null,{timeout});const errors=await page.locator('.kernel-status.error').allTextContents();if(errors.length)throw Error(errors.join(';'))}
async function state(){return page.evaluate(()=>({at:performance.now(),focus:document.hasFocus(),visibility:document.visibilityState,signals:window.__qaSignals,view:window.__qaEditor?.state.view,selection:window.__qaEditor?.state.selection,
 canvas:{...document.querySelector('[data-testid=canvas]')?.dataset},presentation:{...document.querySelector('.kernel-presentation')?.dataset},
 interaction:[...document.querySelectorAll('[data-interaction-mode]')].map(n=>({...n.dataset})),status:[...document.querySelectorAll('.kernel-status')].map(n=>n.textContent)}))}
async function debugPresentation(){return page.evaluate(()=>{
 const canvas=document.querySelector('[data-testid=canvas]'),key=Object.keys(canvas).find(k=>k.startsWith('__reactFiber$')),expected=window.__qaEditor.state.doc,result=[];
 const describe=v=>{if(!v||typeof v!=='object')return null;const f=v.frame||v;if(!f.document)return null;return{currentDocument:f.document===expected,preview:f.preview,key:f.key,revision:f.revision,view:f.view,epoch:f.epoch,width:f.width,height:f.height,pixelRatio:f.pixelRatio,managed:f.managed,rasterProfile:f.rasterProfile,grid:f.grid,checkerboard:f.checkerboard,displayCapability:f.displayCapability}};
 function walk(f){if(!f)return;const p=f.memoizedProps;const row={type:typeof f.type==='string'?f.type:f.type?.name,props:describe(p),presentation:describe(p?.presentation),hooks:[]};let hook=f.memoizedState;while(hook){const d=describe(hook.memoizedState);if(d)row.hooks.push(d);hook=hook.next}if(row.props||row.presentation||row.hooks.length)result.push(row);walk(f.child);walk(f.sibling)}walk(canvas[key]);return{state:{...document.querySelector('.kernel-presentation')?.dataset},surfaces:[...document.querySelectorAll('[data-requested-revision]')].map(n=>({...n.dataset})),fibers:result}})}
async function snapshot(){return page.evaluate(()=>{const e=window.__qaEditor,d=e.state.doc,p=e.parentMap(),rows={};for(const [id,n] of Object.entries(d.nodes)){const parent=p.get(id),siblings=d.nodes[parent]?.children||d.pages.find(x=>x.id===parent)?.children||[];rows[id]={parent,rank:siblings.indexOf(id),transform:n.transform,width:n.width,height:n.height,kind:n.kind,name:n.name}}const images=[];for(const [id,n] of Object.entries(d.nodes))for(const [kind,paints] of [['fills',n.fills],['strokes',n.strokes.map(s=>s.paint)]])for(const paint of paints){if(!paint.image)continue;const base=window.__qaBase?.nodes[id],prior=(kind==='fills'?base?.fills:base?.strokes.map(s=>s.paint))?.find(p=>p.id===paint.id),body=paint.image.slice(paint.image.indexOf(',')+1);images.push({id,kind,paint:paint.id,length:paint.image.length,sameAsImport:prior?.image===paint.image,base64Shape:body.length%4===0&&/^[A-Za-z0-9+/]*={0,2}$/.test(body)})}return{version:e.state.version,page:e.state.page,selection:e.state.selection,rows,images,pages:d.pages.map(p=>({id:p.id,children:p.children}))}})}
async function contentSnapshot(name){
 const captured=await page.evaluate(async()=>{const c=document.querySelector('[data-testid=canvas]');let root=c[Object.keys(c).find(k=>k.startsWith('__reactFiber$'))];while(root.return)root=root.return;root=root.stateNode.current;let client;function walk(f){if(!f||client)return;const p=f.memoizedProps;if(p?.client?.captureContentBitmap&&p?.sourceDocument){client=p.client;return}walk(f.child);walk(f.sibling)}walk(root);if(!client)throw Error('No resident content client');const capture=await client.captureContentBitmap();try{const cv=new OffscreenCanvas(capture.bitmap.width,capture.bitmap.height);cv.getContext('2d').drawImage(capture.bitmap,0,0);const data=new Uint8Array(await(await cv.convertToBlob({type:'image/png'})).arrayBuffer());let binary='';for(let i=0;i<data.length;i+=32768)binary+=String.fromCharCode(...data.subarray(i,i+32768));return{png:btoa(binary),frame:capture.frame}}finally{capture.bitmap.close()}})
 await fs.writeFile(path.join(out,name+'-content.png'),Buffer.from(captured.png,'base64'));await fs.writeFile(path.join(out,name+'-content.json'),JSON.stringify(captured.frame))
}
async function waitSample(){await page.waitForFunction(()=>{const c=document.querySelector('[data-testid=canvas]');let f=c[Object.keys(c).find(k=>k.startsWith('__reactFiber$'))];while(f){let h=f.memoizedState;while(h){const v=h.memoizedState?.current;if(v?.inputSequence&&v?.covers&&v?.isActive){const seq=v.inputSequence(),i=document.querySelector('[data-interaction-mode]')?.dataset;return seq>0&&Number(i?.contentSequence)>=seq&&i?.interactionActive==='true'}h=h.next}f=f.return}return false},null,{timeout:15000})}
async function beginTrace(){await page.evaluate(()=>{window.__qaFrames=[];window.__qaEvents=[];window.__qaLong=[];window.__qaWork=[];window.__qaRecord=true;let previous=performance.now();function tick(at){if(!window.__qaRecord)return;const p=document.querySelector('.kernel-presentation'),i=document.querySelector('[data-interaction-mode]'),c=document.querySelector('.kernel-compositor[data-projected-camera]')?.dataset;window.__qaFrames.push({at,observedAt:performance.now(),projectedCamera:c?.projectedCamera?JSON.parse(c.projectedCamera):null,gap:at-previous,view:window.__qaEditor.state.view,presentation:p?{...p.dataset}:null,interaction:i?Object.fromEntries(['interactionActive','interactionReady','interactionWarming','interactionMode','interactionEnd','interactionError','interactionMoves','interactionSamples','contentSequence','compositorFrames'].map(k=>[k,i.dataset[k]])):null});previous=at;requestAnimationFrame(tick)}requestAnimationFrame(tick)})}
async function endTrace(name){const trace=await page.evaluate(()=>{window.__qaRecord=false;return {signals:window.__qaSignals,timeOrigin:performance.timeOrigin,frames:window.__qaFrames,events:window.__qaEvents,longTasks:window.__qaLong,worker:window.__qaWork}});await fs.writeFile(path.join(out,name+'-trace.json'),JSON.stringify(trace));const gaps=trace.frames.map(f=>f.gap).sort((a,b)=>a-b);return{frames:gaps.length,rafP95:gaps[Math.floor(gaps.length*.95)],rafMax:gaps.at(-1),longTasks:trace.longTasks}}
async function startPixels(name){if(!pixels)return;await fs.mkdir(path.join(out,name+'-frames'));stream={name,frames:[]};await cdp.send('Page.startScreencast',{format:'png',maxWidth:2880,maxHeight:1920,everyNthFrame:1})}
async function stopPixels(){if(!pixels)return;await cdp.send('Page.stopScreencast');const done=stream;stream=null;await Promise.all(writes);writes=[];await fs.writeFile(path.join(out,done.name+'-screencast.json'),JSON.stringify(done.frames));return done.frames.length}
try{
 await stage('launch',async()=>{
  app=await _electron.launch({executablePath:electron,args:[host,'--desktop-isolated-profile'],cwd:root,env,chromiumSandbox:true,timeout:60000})
  for(const s of [app.process().stdout,app.process().stderr])s?.on('data',b=>{void fs.appendFile(path.join(out,'host.log'),b)})
  page=await app.firstWindow();page.setDefaultTimeout(30000);if(process.env.QA_OFFSCREEN_INPUT==='1'){const focus=await page.context().newCDPSession(page);await focus.send('Emulation.setFocusEmulationEnabled',{enabled:true})}page.on('pageerror',e=>{report.errors.push(String(e))});page.on('console',m=>{if(m.text().startsWith('QA_MATERIAL '))void fs.appendFile(path.join(out,'material-fields.ndjson'),m.text().slice(12)+'\n');if(['warning','error'].includes(m.type()))void fs.appendFile(path.join(out,'console.log'),m.text()+'\n')})
  const runtime=await app.evaluate(({app,BrowserWindow},isolated)=>{const w=BrowserWindow.getAllWindows()[0];w.setSize(1440,960);w.setTitle('复杂捕获与呈现 · 独立验证');if(isolated){w.setIgnoreMouseEvents(true);w.setFocusable(false);if(process.env.QA_OFFSCREEN_INPUT==='1'){w.webContents.on('paint',event=>event.texture?.release());w.webContents.setFrameRate(120)}else w.showInactive()}else{w.show();w.focus()}return{pid:process.pid,profile:app.getPath('userData'),versions:process.versions,gpu:app.getGPUFeatureStatus()}},process.env.QA_ISOLATED_INPUT==='1')
  await expect(page.locator('.app-shell')).toHaveAttribute('data-desktop-ready','true',{timeout:60000})
  if(process.env.QA_ISOLATED_INPUT!=='1')await page.waitForFunction(()=>document.hasFocus())
  await page.evaluate(()=>{window.__qaSignals=[];for(const name of ['blur','focus','pointercancel','lostpointercapture'])window.addEventListener(name,e=>{if(window.__qaRecord)window.__qaSignals.push({name,at:performance.now(),target:e.target?.tagName,connected:e.target?.isConnected,buttons:e.buttons,pointerId:e.pointerId})},true);window.__qaRecord=false;const original=Worker.prototype.postMessage,seen=new WeakSet();const record=(kind,d)=>{if(!window.__qaRecord)return;const row={at:performance.now(),kind};for(const key of ['command','type','id','channel','sequence','error','ok','compileMs','graphMs'])if(['string','number','boolean'].includes(typeof d?.[key]))row[key]=d[key];if(d?.command==='display-frame')row.frame={diagnosticSequence:d.frame?.diagnosticSequence,presentationId:d.frame?.presentationId,view:d.frame?.view,overlay:d.frame?.overlay};if(d?.input)row.input={sequence:d.input.sequence,at:d.input.at};if(d?.frame?.input)row.frameInput={sequence:d.frame.input.sequence,at:d.frame.input.at};if(d?.presentation)row.presentation={...d.presentation,residentSample:d.presentation.residentSample};window.__qaWork.push(row)};Worker.prototype.postMessage=function(d,...rest){if(!seen.has(this)){seen.add(this);this.addEventListener('message',e=>record('reply',e.data))}record('send',d);return original.call(this,d,...rest)};
   for(const type of ['pointerdown','pointermove','pointerup'])document.addEventListener(type,e=>{if(window.__qaRecord&&e.target?.closest?.('[data-testid=canvas]'))window.__qaEvents.push({at:performance.now(),type,trusted:e.isTrusted,buttons:e.buttons,pointerId:e.pointerId,x:e.clientX,y:e.clientY,tool:window.__qaEditor?.state.tool,session:window.__qaEditor?.sessionGeneration,selection:window.__qaEditor?.state.selection.slice()})},true);
   const wheels=new WeakMap();document.addEventListener('wheel',e=>{if(window.__qaRecord&&e.target?.closest?.('[data-testid=canvas]')){const row={at:performance.now(),type:'wheel',trusted:e.isTrusted,dx:e.deltaX,dy:e.deltaY,ctrl:e.ctrlKey};window.__qaEvents.push(row);wheels.set(e,row)}},true);window.addEventListener('wheel',e=>{const row=wheels.get(e);if(row)row.view={...window.__qaEditor.effectiveView()}});
   new PerformanceObserver(list=>{if(window.__qaRecord)for(const e of list.getEntries())window.__qaLong.push({at:e.startTime,duration:e.duration})}).observe({type:'longtask'})
  })
  if(pixels){cdp=await page.context().newCDPSession(page);cdp.on('Page.screencastFrame',event=>{void cdp.send('Page.screencastFrameAck',{sessionId:event.sessionId});if(!stream||stream.frames.length>=400)return;const n=stream.frames.length,file=String(n).padStart(4,'0')+'.png';stream.frames.push({file,...event.metadata,receivedAt:performance.now()});writes.push(fs.writeFile(path.join(out,stream.name+'-frames',file),Buffer.from(event.data,'base64')))})}
  return runtime
 })
 await stage('import',async()=>{
  await page.locator('input[type=file][accept*=".fd"]').setInputFiles(source)
  if(path.basename(source).startsWith('拓扑')){
   await expect(page.locator('.app-shell')).toHaveAttribute('data-source-document','true',{timeout:300000})
   const rootName=process.env.QA_ROOT_NAME||'主框架03',rootId=process.env.QA_ROOT_ID||'10c6999a-19ed-4836-be94-46a2609309d7';await page.getByLabel('搜索素材',{exact:true}).fill(rootName);const row=page.locator('.source-page-entry').filter({has:page.getByText(rootName,{exact:true})}).nth(Number(process.env.QA_ROOT_INDEX||0));await expect(row).toBeVisible({timeout:300000});if(process.env.QA_FULL_SOURCE==='1')await row.click();else{await row.dblclick();await expect(page.getByTestId('layer-'+rootId)).toBeVisible({timeout:240000})}
  }else await expect(page.getByLabel('文档名称',{exact:true})).toHaveValue(process.env.QA_DOCUMENT_NAME || path.basename(source).replace(/\.(fig|sketch)$/,''),{timeout:240000})
  await settle();
  if(process.env.QA_FULL_SOURCE==='1')return await page.evaluate(()=>{const c=document.querySelector('[data-testid=canvas]'),k=Object.keys(c).find(v=>v.startsWith('__reactFiber'));let f=c[k],e;while(f){if(f.memoizedProps?.editor?.state){e=f.memoizedProps.editor;break}f=f.return};if(!e)throw Error('No source canvas editor');window.__qaEditor=e; const v=e.state.view;window.__qaTarget={point:{x:(c.clientWidth/2-v.x)/v.zoom,y:(c.clientHeight/2-v.y)/v.zoom}};return {fullSource:true,view:v,ready:document.querySelector('.native-source-surface .kernel-status').textContent}})
  const targets=await page.evaluate(targetId=>{
   const canvas=document.querySelector('[data-testid=canvas]'),key=Object.keys(canvas).find(k=>k.startsWith('__reactFiber$'));let f=canvas[key],e;while(f){if(f.memoizedProps?.editor?.state){e=f.memoizedProps.editor;break}f=f.return}if(!e)throw Error('Missing canvas editor');window.__qaEditor=e;
   e.select([]);const d=e.state.doc,entries=e.entries(),byId=new Map(entries.map(x=>[x.id,x])),candidates=[];
   const eligible=entries.filter(x=>{const n=d.nodes[x.id];return x.ancestors.length&&n.visible&&!n.locked&&!n.instanceOrigin&&!n.component&&!n.children.length&&x.bounds.width>=6&&x.bounds.height>=6&&x.bounds.width<350&&x.bounds.height<160}).sort((a,b)=>b.ancestors.length-a.ancestors.length)
   for(const x of eligible){const point={x:x.bounds.x+x.bounds.width/2,y:x.bounds.y+x.bounds.height/2};if(e.hoverHit(point,undefined,1)!==x.id)continue;const chain=x.ancestors.map(id=>d.nodes[id]);if(chain.some(n=>n.instance||n.instanceOrigin||n.layout&&n.layout.mode!=='none'))continue;
    const frame=[...chain].reverse().find(n=>n.kind==='frame'||n.kind==='section')||chain[0],entry=frame&&byId.get(frame.id);if(!entry)continue;const [a,b,c,dd,tx,ty]=entry.matrix,det=a*dd-b*c;const inside=p=>{const px=p.x-tx,py=p.y-ty,lx=(dd*px-c*py)/det,ly=(-b*px+a*py)/det;return lx>1&&ly>1&&lx<frame.width-1&&ly<frame.height-1};if(!inside(point)||!inside({x:point.x+6,y:point.y}))continue;
    candidates.push({id:x.id,name:d.nodes[x.id].name,kind:d.nodes[x.id].kind,bounds:x.bounds,point,ancestors:x.ancestors.map(id=>({id,name:d.nodes[id].name,kind:d.nodes[id].kind,width:d.nodes[id].width,height:d.nodes[id].height})),frame:frame.id});if(candidates.length>=8)break
   }
   if(targetId){const x=byId.get(targetId),n=d.nodes[targetId];if(!x||!n)throw Error('Missing requested fixture target');const probe=Array.from({length:81},(_,i)=>({x:x.bounds.x+(i%9+1)*x.bounds.width/10,y:x.bounds.y+(Math.floor(i/9)+1)*x.bounds.height/10})).find(p=>{const hit=e.hoverHit(p,undefined,1);return hit===x.id||!!hit&&byId.get(hit)?.ancestors.includes(x.id)});candidates.unshift({id:x.id,name:n.name,kind:n.kind,bounds:x.bounds,point:probe||{x:x.bounds.x+x.bounds.width/2,y:x.bounds.y+x.bounds.height/2},ancestors:x.ancestors.map(id=>({id,name:d.nodes[id].name,kind:d.nodes[id].kind,width:d.nodes[id].width,height:d.nodes[id].height})),frame:x.ancestors[0]})}
   if(!candidates.length)throw Error('No free nested sample');window.__qaTarget=candidates[0];window.__qaBase=d;
   return {multiEffects:entries.filter(x=>d.nodes[x.id].effects.filter(e=>e.visible).length>1).map(x=>({id:x.id,name:d.nodes[x.id].name,effects:d.nodes[x.id].effects.filter(e=>e.visible).map(e=>({kind:e.kind,radius:e.radius,x:e.x,y:e.y})),bounds:x.bounds,ancestors:x.ancestors})),nodes:Object.keys(d.nodes).length,roots:d.pages.find(p=>p.id===e.state.page).children,candidates,profile:d.rasterProfile,color:d.colorManagement}
  },process.env.QA_TARGET_ID);if(process.env.QA_INSPECT==='1'){await fs.writeFile(path.join(out,'document.json'),await page.evaluate(()=>JSON.stringify(window.__qaEditor.state.doc)));await fs.writeFile(path.join(out,'scene.json'),await page.evaluate(()=>JSON.stringify(window.__qaEditor.entries())))}await page.screenshot({path:path.join(out,'import.png')});return targets
 })

 const shots=[]
 const reset=(view)=>page.evaluate(v=>{const e=window.__qaEditor;e.select([]);e.discardPendingView();e.set({view:v})},view)
 const canvas=page.getByTestId('canvas'),size=await canvas.boundingBox(),sw=Math.floor(size.width),sh=Math.floor(size.height)
 const camera=()=>page.evaluate(()=>({...window.__qaEditor.state.view}))
 const renderState=()=>page.evaluate(()=>{const state={};const all=[...document.querySelectorAll('.kernel-compositor')];for(const n of all){const key=Object.keys(n.parentElement).find(k=>k.startsWith('__reactFiber'));let f=n.parentElement[key];while(f){const pr=f.memoizedProps;if(pr?.items && pr?.contentRevision){state.overviewCandidates=pr.overviewTiles?.map(q=>({id:q.gpuTile,zoom:q.zoom,x:q.x,y:q.y}));state.extent=pr.overview;state.items=pr.items.filter(it=>it.active).map(it=>({zoom:it.tile.zoom,x:it.tile.x,y:it.tile.y,w:it.tile.width,h:it.tile.height,ov:it.tile.overview})).slice(0,50);state.scope=[pr.contentRevision,pr.presentation?.epoch,pr.presentation?.gpuOverlayIdentity,pr.overlay?.uiIdentity];}for(let h=f.memoizedState;h;h=h.next){const v=h.memoizedState?.current;if(v?.history){state.historyFrame=v.history.frame;state.atlas={grant:v.history.granted,tried:v.history.tried?.size,covered:v.history.atlas?.covered?.size,extent:v.history.atlas?.bounds,copying:v.history.copying}}if(v?.actual?.view&&v?.client&&v?.source){state.actual={view:v.actual.view,preview:v.actual.preview,sourcePreview:v.source?.preview,allow:v.actual.navigationBackingBytes};}}f=f.return}}const tiles=document.querySelector('.kernel-tiles');Object.assign(state,{overview:tiles?.dataset.overviewTiles,tiles:tiles?.dataset.tileCount,full:tiles?.dataset.nativePixelReady});const c=document.querySelector('.kernel-compositor'); const f=document.querySelector('.kernel-presentation');const h=document.querySelector('.native-source-surface [data-camera-history]'), hc=h?.querySelector('canvas')
  Object.assign(state,{sourceHistory:h&&{clip:h.style.clipPath,display:h.style.display,transform:hc?.style.transform,width:hc?.width,height:hc?.height}})
  return {...state,view:{...window.__qaEditor.state.view},ready:f?.dataset.presentationReady,pixels:c?.dataset.previewPendingPixels,transform:c?.style.transform,cache:c?.dataset.previewCachedPixels,history:document.querySelector('[data-camera-history]')?.getAttribute('style')}})
 async function screen(name){
  const info=await renderState()
  const shot=await app.evaluate(async({BrowserWindow},r)=>{const w=BrowserWindow.getAllWindows()[0];const image=await w.webContents.capturePage(r);return image.toPNG().toString('base64')},{x:Math.round(size.x+12),y:Math.round(size.y+60),width:sw-24,height:sh-120})
  await fs.writeFile(path.join(out,name+'.png'),Buffer.from(shot,'base64'));shots.push({name,...info})
 }
 await stage('camera-tiles',async()=>{
  const base=await camera();await screen('open');const target=await page.evaluate(()=>window.__qaTarget.point)
  const narrow=Math.max(base.zoom*3,0.8)
  const inner={x:sw/2-target.x*narrow,y:sh/2-target.y*narrow,zoom:narrow}
  await reset(inner);await settle();await screen('start')
  const x=size.x+sw*.5,y=size.y+sh*.5
  await page.mouse.move(x,y)
  for(let i=0;i<7;i++) {await page.mouse.wheel(Number(process.env.QA_PAN_DX||75),0);await page.waitForTimeout(13)}
  await page.waitForTimeout(19);await screen('pan-early');await settle();await screen('pan-exact')
  for(let i=0;i<7;i++){await page.mouse.wheel(-Number(process.env.QA_PAN_DX||75),0);await page.waitForTimeout(13)}
  await settle()
  await page.keyboard.down('Control')
  for(let i=0;i<8;i++){await page.mouse.wheel(0,90);await page.waitForTimeout(12)}
  await page.keyboard.up('Control');await page.waitForTimeout(20);await screen('zoom-early');await settle();await screen('zoom-exact')
  await page.keyboard.down('Control')
  for(const dy of [-70,-70,-70,-70,70,70,-70,-70,70,70]){await page.mouse.wheel(0,dy);await page.waitForTimeout(11)}
  await page.keyboard.up('Control');await page.waitForTimeout(22);await screen('reverse-early');await settle();await screen('reverse-exact')
  return {shots,input:'Electron wheel, CSS pan and Ctrl+wheel zoom'}
 })
 await stage('template-zoom-chain',async()=>{
   const high={x:-364116.5,y:-212420,zoom:32};const focus={x:(sw/2-high.x)/32,y:(sh/2-high.y)/32};const steps=[];
   for(const z of [32,1.25,9.5,0.4036458333333333]){
     const v=z===32?high:{x:sw/2-focus.x*z,y:sh/2-focus.y*z,zoom:z};const start=performance.now();await reset(v);
     await page.waitForFunction(v=>{const el=document.querySelector('.native-source-content');return el?.dataset.projectedCamera===JSON.stringify(v)},v,{timeout:180000});const projectedMs=performance.now()-start;
     await settle(180000);await page.waitForFunction(v=>{const el=document.querySelector('.native-source-content');return el?.dataset.projectedCamera===JSON.stringify(v)&&el.dataset.cameraReprojected==='false'&&document.querySelector('.native-source-surface .kernel-status')?.textContent==='WebGPU · 清晰'},v,{timeout:180000});const exactMs=performance.now()-start;
     if(z===32){const png=await page.locator('canvas.native-source-content').evaluate(c=>c.toDataURL('image/png').split(',')[1]);await fs.writeFile(path.join(out,'template2-native-3200.png'),Buffer.from(png,'base64'))}
     steps.push({zoom:z,projectedMs,exactMs});
   }
   return{steps};
 })
 report.memory=await app.evaluate(({app})=>app.getAppMetrics().map(m=>({type:m.type,memory:m.memory,cpu:m.cpu})));report.status='completed-replay'
}catch(e){report.status='failed';report.error=String(e);if(page&&!page.isClosed()){await page.screenshot({path:path.join(out,'failure.png')}).catch(()=>{});await fs.writeFile(path.join(out,'failure-state.json'),JSON.stringify(await state().catch(()=>null),null,2));await endTrace('failure').catch(()=>{});await stopPixels().catch(()=>{})}}
finally{report.sourceUnchanged=hash(await fs.readFile(source))===sourceHash;await persist();if(app){const child=app.process();await Promise.race([app.evaluate(({app})=>app.exit(0)).catch(()=>{}),new Promise(r=>setTimeout(r,3000))]);if(child.exitCode===null)child.kill('SIGKILL')}}
console.log(JSON.stringify({status:report.status,error:report.error,out}));if(report.status==='failed')process.exitCode=1
